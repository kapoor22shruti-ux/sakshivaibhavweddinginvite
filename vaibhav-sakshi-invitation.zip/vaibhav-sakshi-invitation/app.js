(()=>{
const W=WEDDING,$=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
let lang=localStorage.getItem('lang')||'en';
const bride=()=>location.hash==='#bride';
const get=(o,p)=>p.split('.').reduce((a,k)=>a&&a[k],o);
const split=(t,l)=>(l==='hi'?t.split(' '):[...t]).map((c,i,a)=>`<span style="animation-delay:${.9+i*(l==='hi'?.25:.07)}s">${c===' '?'&nbsp;':c}</span>${l==='hi'&&i<a.length-1?' ':''}`).join('');
const names=(t)=>{const n=t.names,a=bride()?[n.bride,n.groom]:[n.groom,n.bride];return a};
function render(){
 const t=I18N[lang];document.documentElement.lang=lang;document.body.classList.toggle('hi',lang==='hi');document.title=t.title;
 $$('[data-i]').forEach(e=>e.innerHTML=get(t,e.dataset.i));
 const [a,b]=names(t);
 $$('[data-names]').forEach(e=>{e.setAttribute('aria-label',a+' & '+b);e.innerHTML=lang==='hi'?split(a+' & '+b,'hi'):split(a+' & '+b,'en')});
 $$('[data-names-s]').forEach(e=>e.textContent=a+' & '+b);
 $$('[data-lang]').forEach(e=>e.textContent=t.lang);
 $('[data-late]').innerHTML=t.late.join('<br>');
 $('#guests').innerHTML=t.guests.map(g=>`<li>${g}</li>`).join('');
 const tel=$('#tel');tel.textContent=W.rsvp.phone;tel.href='tel:'+W.rsvp.tel;
 $('#tl').innerHTML='<i class="thread"><i id="fill"></i></i>'+W.events.map(e=>{const v=t.ev[e.id];return `<article class="ev"><span class="ic">${e.icon}</span><h3>${v.n}</h3><p>${v.day}</p><p class="b">${v.t}</p><p>${v.d}</p>${e.muhurat?`<p class="mu">${v.m}</p>`:''}
 <div class="venue"><b>${t.venue}</b><br>${t.addr}</div>
 <a class="btn o s" href="${W.mapsUrl}" target="_blank" rel="noopener">${t.dir}</a><a class="btn o s" href="${gcal(e,v)}" target="_blank" rel="noopener">${t.gcal}</a><a class="btn o s" href="#" data-ics="${e.id}">${t.ics}</a>
 ${e.muhurat&&W.video?`<br><button class="btn s" data-film>${t.film}</button>`:''}</article>`}).join('');
 $('#mas').innerHTML=(W.gallery.length?W.gallery:[1,2,3,4,5,6]).map((g,i)=>`<figure data-g="${i}">${W.gallery.length?`<img loading="lazy" src="${g}" alt="">`:`<div class="ph">${t.galSoon}</div>`}</figure>`).join('');
 $('#wa').href='https://wa.me/?text='+encodeURIComponent(t.title+' '+url());
 scroll();
}
const url=()=>W.siteUrl||location.href.split('#')[0];
const stamp=(d,tm,add=0)=>{const x=new Date(`${d}T${tm}:00+05:30`);x.setHours(x.getHours()+add);return x.toISOString().replace(/[-:]|\.\d+/g,'')};
const gcal=(e,v)=>{const t=I18N[lang];return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text='+encodeURIComponent(v.n+' – Vaibhav & Sakshi')+'&dates='+stamp(e.date,e.time)+'/'+stamp(e.date,e.time,W.calHours)+'&location='+encodeURIComponent(t.venue+', '+t.addr)+'&details='+encodeURIComponent(v.d)};
document.addEventListener('click',ev=>{
 const a=ev.target.closest('[data-ics]');
 if(a){ev.preventDefault();const e=W.events.find(x=>x.id===a.dataset.ics),v=I18N[lang].ev[e.id];
  const s=`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Wedding//EN\r\nBEGIN:VEVENT\r\nUID:${e.id}@vaibhav-sakshi\r\nDTSTAMP:${stamp(e.date,e.time)}\r\nDTSTART:${stamp(e.date,e.time)}\r\nDTEND:${stamp(e.date,e.time,W.calHours)}\r\nSUMMARY:${v.n} – Vaibhav & Sakshi\r\nLOCATION:${I18N[lang].venue}\\, ${I18N[lang].addr.replace(/,/g,'\\,')}\r\nURL:${W.mapsUrl}\r\nEND:VEVENT\r\nEND:VCALENDAR`;
  const l=document.createElement('a');l.href=URL.createObjectURL(new Blob([s],{type:'text/calendar'}));l.download=e.id+'.ics';l.click()}
 if(ev.target.closest('[data-lang]')){lang=lang==='en'?'hi':'en';localStorage.setItem('lang',lang);render();show()}
 if(ev.target.closest('[data-film]')){window.open(W.video,'_blank');au&&au.pause()}
 const f=ev.target.closest('[data-g]');if(f&&W.gallery.length)lb(+f.dataset.g);
});
window.addEventListener('hashchange',render);
/* audio */
let au=null;const mb=$('#music');
if(W.audio){au=new Audio(W.audio);au.loop=true;au.volume=.5;au.addEventListener('canplaythrough',()=>mb.hidden=false,{once:true});au.onerror=()=>{au=null;mb.hidden=true}}
const sync=()=>{mb.textContent=au&&!au.paused?'❚❚':'♪'};
mb.onclick=()=>{au&&(au.paused?au.play():au.pause());sync()};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&au){au.pause();sync()}});
/* gate */
const show=()=>{document.body.classList.remove('show');void document.body.offsetWidth;document.body.classList.add('show')};
$('#open').onclick=()=>{
 const g=$('#gate');g.classList.add('opened');if(au){au.play().then(()=>{mb.hidden=false;sync()}).catch(()=>{})}
 burst();setTimeout(()=>{g.classList.add('gone');document.body.classList.remove('locked');show()},2400);
};
/* countdown */
const cd=$$('#cd b');setInterval(tick,1000);function tick(){let d=Math.max(0,new Date(W.muhurat)-Date.now())/1000;
 [d/86400,d/3600%24,d/60%60,d%60].forEach((v,i)=>cd[i].textContent=String(Math.floor(v)).padStart(2,'0'))}tick();
/* timeline fill */
function scroll(){const t=$('#tl'),f=$('#fill');if(!t||!f)return;const r=t.getBoundingClientRect(),p=Math.min(1,Math.max(0,(innerHeight*.7-r.top)/r.height));f.style.height=p*100+'%'}
/* share */
$('#share').onclick=async()=>{const t=I18N[lang];if(navigator.share){try{await navigator.share({title:t.title,url:url()})}catch(e){}}else window.open($('#wa').href,'_blank')};
$('#cp').onclick=async()=>{try{await navigator.clipboard.writeText(url())}catch(e){}toast(I18N[lang].copied)};
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),1800)}
/* lightbox */
function lb(i){const L=$('#lb'),n=W.gallery.length;const set=()=>$('#li').innerHTML=`<img src="${W.gallery[i]}" alt="">`;set();L.hidden=false;let x0=0;
 L.ontouchstart=e=>x0=e.touches[0].clientX;L.ontouchend=e=>{const d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40){i=(i+(d<0?1:n-1))%n;set()}};
 $('#lx').onclick=()=>L.hidden=true}
/* flowers canvas: 3 parallax layers, per-section flower, wind on fast scroll */
const FL={rose:['#c1273d','#e04a5f','#fff6e8'],genda:['#f59a1b','#ffb938','#f7c948'],lotusrose:['#f4a7bb','#c1273d','#fff0f3'],lotus:['#f48fb1','#f8bbd0','#fce4ec'],ashoka:['#5f8a3c','#7da650','#f59a1b'],bougain:['#d6336c','#e64980','#9c36b5'],gold:['#c1273d','#C29B58','#e8cf94']};
const cv=$('#fx'),cx=cv.getContext('2d');let P=[],cur='rose',wind=0,lastY=0,burstMode=false;
const size=()=>{cv.width=innerWidth*devicePixelRatio;cv.height=innerHeight*devicePixelRatio;cx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)};size();addEventListener('resize',size);
const mk=(layer,top)=>({x:Math.random()*innerWidth,y:top?-20:Math.random()*innerHeight,l:layer,s:[5,8,13][layer]*(.7+Math.random()*.6),v:[.25,.5,.9][layer],r:Math.random()*6,w:Math.random()*2,c:Math.random()*3|0,o:[.35,.55,.8][layer]});
function seed(n){P=Array.from({length:n},(_,i)=>mk(i%3))}
function burstPetals(){burstMode=true;P=[];for(let i=0;i<90;i++){const p=mk(i%3,true);p.y=-Math.random()*innerHeight;p.mc=Math.random()<.5?'#f5a623':'#c1273d';p.v*=2.2;P.push(p)}setTimeout(()=>{burstMode=false;seed(RM?0:24)},7000)}
function burst(){if(!RM)burstPetals()}
function petal(p,cols){cx.save();cx.translate(p.x,p.y);cx.rotate(p.r);cx.globalAlpha=p.o;cx.fillStyle=p.mc||cols[p.c];
 if(cur==='ashoka'&&!burstMode&&p.c<2){cx.beginPath();cx.ellipse(0,0,p.s*.35,p.s*1.2,0,0,6.3)}else{cx.beginPath();cx.ellipse(0,0,p.s*.5,p.s,0,0,6.3)}cx.fill();
 if(cur==='gold'&&p.c===1&&!burstMode){cx.shadowColor='#C29B58';cx.shadowBlur=6}cx.restore()}
function loop(){cx.clearRect(0,0,innerWidth,innerHeight);const cols=FL[cur];wind*=.95;
 P.forEach(p=>{p.y+=p.v*(1+Math.abs(wind)*.15);p.x+=Math.sin(p.w+=.02)*.5*p.v+wind*p.v*.6;p.r+=.01*p.v;
  if(p.y>innerHeight+20||p.x<-30||p.x>innerWidth+30){Object.assign(p,mk(p.l,true));if(burstMode){p.mc=Math.random()<.5?'#f5a623':'#c1273d'}}petal(p,cols)});requestAnimationFrame(loop)}
if(!RM){seed(24);loop()}
addEventListener('scroll',()=>{const y=scrollY;wind=Math.max(-40,Math.min(40,(y-lastY)*.5));lastY=y;scroll();
 const m=innerHeight/2;for(const s of $$('section')){const r=s.getBoundingClientRect();if(r.top<m&&r.bottom>m){cur=s.dataset.flower||cur;break}}},{passive:true});
render();
})();
