// All wedding data lives here. Edit only this file (and i18n.js for wording).
window.WEDDING={
 siteUrl:"",            // add your live URL for Open Graph / sharing
 tz:"Asia/Kolkata",
 audio:"assets/music.mp3",   // background instrumental (add file)
 video:"",                   // optional invitation film URL / file (empty = button hidden)
 mapsUrl:"https://share.google/klpq0WMhooNYNZcXO",
 calHours:3,                 // calendar block length (card gives no end times)
 muhurat:"2026-12-02T13:00:00+05:30",
 events:[
  {id:"sufi",date:"2026-12-01",time:"19:00",icon:"♪"},
  {id:"wedding",date:"2026-12-02",time:"13:00",icon:"ॐ",muhurat:true},
  {id:"reception",date:"2026-12-02",time:"20:00",icon:"❀"}
 ],
 rsvp:{phone:"9415029744",tel:"+919415029744"},
 gallery:[] // e.g. ["assets/g1.jpg","assets/g2.jpg"]; empty = Jharokha placeholder frames
};
